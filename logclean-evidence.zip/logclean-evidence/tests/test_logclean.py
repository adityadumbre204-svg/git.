import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from datetime import datetime
import os


SCRIPT = Path(__file__).resolve().parents[1] / "logclean.py"


class LogcleanTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.logs = self.root / "logs"
        self.logs.mkdir()

        self.old_log = self.logs / "old.log"
        self.old_log.write_text("old log data")
        old_time = datetime(2026, 10, 1, 12, 0).timestamp()
        os.utime(self.old_log, (old_time, old_time))

        self.recent_log = self.logs / "recent.log"
        self.recent_log.write_text("recent log data")

    def tearDown(self):
        self.temp.cleanup()

    def run_tool(self, *args):
        return subprocess.run(
            [sys.executable, str(SCRIPT), *map(str, args)],
            capture_output=True,
            text=True,
        )

    def test_dry_run_does_not_delete_old_file(self):
        result = self.run_tool(
            "--older-than", "7", str(self.logs), "--dry-run"
        )
        self.assertEqual(result.returncode, 0)
        self.assertIn("old.log", result.stdout)
        self.assertTrue(self.old_log.exists())
        self.assertIn("Dry run", result.stdout)

    def test_recent_file_is_not_selected(self):
        result = self.run_tool(
            "--older-than", "7", str(self.logs), "--dry-run"
        )
        self.assertNotIn("recent.log", result.stdout)

    def test_invalid_age_is_rejected(self):
        result = self.run_tool(
            "--older-than", "-3", str(self.logs), "--dry-run"
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("greater than zero", result.stderr)

    def test_missing_directory_is_rejected(self):
        result = self.run_tool(
            "--older-than", "7",
            str(self.root / "missing"), "--dry-run"
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("does not exist", result.stderr)

    def test_declining_confirmation_preserves_file(self):
        result = subprocess.run(
            [
                sys.executable, str(SCRIPT),
                "--older-than", "7", str(self.logs)
            ],
            input="n\n",
            capture_output=True,
            text=True,
        )
        self.assertEqual(result.returncode, 0)
        self.assertTrue(self.old_log.exists())
        self.assertIn("Cancelled", result.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
