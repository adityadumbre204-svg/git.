#!/usr/bin/env python3

import argparse
import fnmatch
import sys
import time
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(
        description="Safely find and remove old log files."
    )
    parser.add_argument(
        "directory",
        help="Directory to scan"
    )
    parser.add_argument(
        "-a", "--older-than",
        type=float,
        required=True,
        help="File age threshold in days"
    )
    parser.add_argument(
        "-p", "--pattern",
        default="*.log",
        help="Filename pattern (default: *.log)"
    )
    parser.add_argument(
        "-n", "--dry-run",
        action="store_true",
        help="Preview matching files without deleting"
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show additional information"
    )
    parser.add_argument(
        "--yes",
        action="store_true",
        help="Delete without interactive confirmation"
    )

    args = parser.parse_args()

    if args.older_than <= 0:
        parser.error("--older-than must be greater than zero")

    root = Path(args.directory).expanduser()

    if not root.is_dir():
        print(f"Error: directory does not exist: {root}", file=sys.stderr)
        return 2

    cutoff = time.time() - args.older_than * 86400
    matches = []

    try:
        for path in root.rglob("*"):
            if path.is_symlink() or not path.is_file():
                continue
            if not fnmatch.fnmatch(path.name, args.pattern):
                continue
            try:
                if path.stat().st_mtime < cutoff:
                    matches.append(path)
            except OSError as exc:
                print(f"Warning: cannot inspect {path}: {exc}", file=sys.stderr)

    except OSError as exc:
        print(f"Error scanning directory: {exc}", file=sys.stderr)
        return 1

    print(f"Directory: {root}")
    print(f"Pattern: {args.pattern}")
    print(f"Older than: {args.older_than:g} days")

    if not matches:
        print("No matching files found.")
        return 0

    print(f"Matching files: {len(matches)}")
    for path in matches:
        if args.verbose:
            print(f"  {path} ({path.stat().st_size} bytes)")
        else:
            print(f"  {path}")

    if args.dry_run:
        print("Dry run: no files deleted.")
        return 0

    if not args.yes:
        try:
            answer = input("Delete these files? [y/N]: ").strip().lower()
        except EOFError:
            print("No confirmation received. Nothing deleted.")
            return 1
        if answer != "y":
            print("Cancelled. No files deleted.")
            return 0

    failed = 0
    deleted = 0

    for path in matches:
        try:
            # Recheck age and file type immediately before deletion.
            if path.is_symlink() or not path.is_file():
                print(f"Skipped changed file: {path}", file=sys.stderr)
                failed += 1
                continue
            if path.stat().st_mtime >= cutoff:
                print(f"Skipped file no longer old enough: {path}")
                failed += 1
                continue
            path.unlink()
            deleted += 1
            if args.verbose:
                print(f"Deleted: {path}")
        except OSError as exc:
            print(f"Error deleting {path}: {exc}", file=sys.stderr)
            failed += 1

    print(f"Deleted: {deleted}; failed/skipped: {failed}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
